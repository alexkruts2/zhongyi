<?php

return [
    'cos_img_url' => 'https://hcimg-1251005197.file.myqcloud.com',
    'cos_video_url' => 'https://hcvideo-1251005197.file.myqcloud.com',
    'cos_file_url' => 'https://hcfile-1251005197.file.myqcloud.com',
    'server_url' => 'https://www.haichaoo.com',
    'base_path' => '/webapp/haichao-web-v3/public',
    'image_path' => '/uploads/images/',
    'video_path' => '/uploads/videos/',
    'file_path' => '/uploads/files/',
    'weixin_pay'=> 'WEIXIN_PAY',
    'zhifubao_pay'=> 'ZHIFUBAO_PAY',
    'avatar_path' => '/uploads/avatars/'
];
