<?php

return [
    'shenjian'=>[
        "user_key"=>'b687d512a3-NTQ4ZWFiMD',
        "secret"=>'JiNjg3ZDUxMmEzND-4859566a07548ea'
    ],
    "trading_economy"=>"TE",
    "airbnb"=>"AIRBNB",
    "suburb_profile"=>"SUBURBPROFILE",
    "realestate"=>"REALESTATE",
    "weixin"=>"WEIXIN"
];