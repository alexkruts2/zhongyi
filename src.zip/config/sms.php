<?php

return [
    'appid' => '1400050461',
    'appkey' => 'e76a09728ddea6dbaaec00f928df81b1',
    'chinese' => [
        'signId' => 167382,
        'tpl' => 221702
    ],
    'foreign' => [
        'signId' => 177580,
        'tpl' => 221664
    ],
    'templ_contents' => '您好，欢迎使用海潮的服务。您本次登录的验证码为{1}，请于{2}分钟内填写。如非本人操作，请忽略本短信。',
    'sign' => '海潮助手'
];